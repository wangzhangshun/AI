from django.apps import AppConfig


class TestsysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'testsys'
    verbose_name='测试管理'
