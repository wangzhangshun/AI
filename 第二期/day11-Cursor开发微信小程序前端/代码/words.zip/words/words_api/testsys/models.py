from django.db import models
from users.models import User
from words.models import Question

# Create your models here.

class TestRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='用户')
    score = models.IntegerField('得分')
    vocab_estimate = models.IntegerField('词汇量估算')
    created_at = models.DateTimeField('测试时间', auto_now_add=True)

    class Meta:
        verbose_name = '测试记录'
        verbose_name_plural = '测试记录'

    def __str__(self):
        return f"{self.user.nickname or self.user.openid} - {self.created_at}"

class TestDetail(models.Model):
    record = models.ForeignKey(TestRecord, on_delete=models.CASCADE, related_name='details', verbose_name='测试记录')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, verbose_name='题目')
    user_answer = models.CharField('用户答案', max_length=1)
    is_correct = models.BooleanField('是否正确')

    class Meta:
        verbose_name = '测试明细'
        verbose_name_plural = '测试明细'

    def __str__(self):
        return f"{self.record} - {self.question.word.word}"
