from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import TestRecord, TestDetail
from .serializers import TestRecordSerializer
from users.models import User
from words.models import Question

# Create your views here.

class SubmitTestView(APIView):
    def post(self, request):
        openid = request.data.get('openid')
        answers = request.data.get('answers', [])  # [{question_id, user_answer}, ...]
        vocab_estimate = request.data.get('vocab_estimate', 0)
        score = request.data.get('score', 0)
        if not openid or not answers:
            return Response({'error': 'openid and answers required'}, status=400)
        try:
            user = User.objects.get(openid=openid)
        except User.DoesNotExist:
            return Response({'error': 'user not found'}, status=404)
        record = TestRecord.objects.create(user=user, score=score, vocab_estimate=vocab_estimate)
        for ans in answers:
            try:
                q = Question.objects.get(id=ans['question_id'])
            except Question.DoesNotExist:
                continue
            is_correct = (ans['user_answer'] == q.answer)
            TestDetail.objects.create(record=record, question=q, user_answer=ans['user_answer'], is_correct=is_correct)
        return Response({'record_id': record.id})

class TestHistoryView(APIView):
    def get(self, request):
        openid = request.query_params.get('openid')
        if not openid:
            return Response({'error': 'openid required'}, status=400)
        try:
            user = User.objects.get(openid=openid)
        except User.DoesNotExist:
            return Response({'error': 'user not found'}, status=404)
        records = TestRecord.objects.filter(user=user).order_by('-created_at')[:20]
        serializer = TestRecordSerializer(records, many=True)
        return Response(serializer.data)
