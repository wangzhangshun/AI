from rest_framework import serializers
from .models import TestRecord, TestDetail
from words.serializers import QuestionSerializer

class TestDetailSerializer(serializers.ModelSerializer):
    question = QuestionSerializer()
    class Meta:
        model = TestDetail
        fields = ['id', 'question', 'user_answer', 'is_correct']

class TestRecordSerializer(serializers.ModelSerializer):
    details = TestDetailSerializer(many=True, read_only=True)
    class Meta:
        model = TestRecord
        fields = ['id', 'user', 'score', 'vocab_estimate', 'created_at', 'details'] 