from django.contrib import admin
from .models import TestRecord, TestDetail

@admin.register(TestRecord)
class TestRecordAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'score', 'vocab_estimate', 'created_at')
    search_fields = ('user__nickname', 'user__openid')
    list_filter = ('created_at',)

@admin.register(TestDetail)
class TestDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'record', 'question', 'user_answer', 'is_correct')
    search_fields = ('record__user__nickname', 'question__word__word')
    list_filter = ('is_correct',)
