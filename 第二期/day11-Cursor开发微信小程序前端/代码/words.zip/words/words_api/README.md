# 英语单词量测试小程序 后端API文档

## 用户相关
### 1. 微信登录
- 路径：`POST /api/login/`
- 参数：
  - openid (string, 必填)
  - nickname (string, 可选)
  - avatar (string, 可选)
- 返回：用户信息

### 2. 获取用户信息
- 路径：`GET /api/user/profile/?openid=xxx`
- 参数：openid (string, 必填)
- 返回：用户信息

## 单词与题库相关
### 3. 获取单词列表
- 路径：`GET /api/words/`
- 返回：单词列表

### 4. 获取题目列表
- 路径：`GET /api/questions/?difficulty=1&num=10`
- 参数：difficulty (int, 可选), num (int, 可选，默认10)
- 返回：题目列表

## 测试相关
### 5. 提交测试答案
- 路径：`POST /api/test/submit/`
- 参数：
  - openid (string, 必填)
  - answers (list, 必填) 例：[{question_id: 1, user_answer: 'A'}, ...]
  - vocab_estimate (int, 必填)
  - score (int, 必填)
- 返回：{record_id: int}

### 6. 获取历史测试记录
- 路径：`GET /api/test/history/?openid=xxx`
- 返回：测试记录列表

---
如需详细字段说明或返回示例，请参考各app的serializers定义。 