"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from users.views import WechatLoginView, UserProfileView
from words.views import WordListView, QuestionListView
from testsys.views import SubmitTestView, TestHistoryView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/login/', WechatLoginView.as_view()),
    path('api/user/profile/', UserProfileView.as_view()),
    path('api/words/', WordListView.as_view()),
    path('api/questions/', QuestionListView.as_view()),
    path('api/test/submit/', SubmitTestView.as_view()),
    path('api/test/history/', TestHistoryView.as_view()),
]
