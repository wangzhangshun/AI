from django.contrib import admin
from .models import User

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'openid', 'nickname', 'avatar', 'created_at')
    search_fields = ('openid', 'nickname')
    list_filter = ('created_at',)
