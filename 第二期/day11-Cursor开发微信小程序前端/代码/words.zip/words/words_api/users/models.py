from django.db import models

# Create your models here.

class User(models.Model):
    openid = models.CharField('微信OpenID', max_length=64, unique=True)
    nickname = models.CharField('昵称', max_length=64, blank=True, null=True)
    avatar = models.URLField('头像', max_length=256, blank=True, null=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '用户'
        verbose_name_plural = '用户'

    def __str__(self):
        return self.nickname or self.openid
