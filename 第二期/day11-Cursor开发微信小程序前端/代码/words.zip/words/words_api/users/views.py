from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import User
from .serializers import UserSerializer

# Create your views here.

class WechatLoginView(APIView):
    def post(self, request):
        openid = request.data.get('openid')
        nickname = request.data.get('nickname', '')
        avatar = request.data.get('avatar', '')
        if not openid:
            return Response({'error': 'openid required'}, status=400)
        user, created = User.objects.get_or_create(openid=openid, defaults={'nickname': nickname, 'avatar': avatar})
        if not created:
            user.nickname = nickname or user.nickname
            user.avatar = avatar or user.avatar
            user.save()
        return Response(UserSerializer(user).data)

class UserProfileView(APIView):
    def get(self, request):
        openid = request.query_params.get('openid')
        if not openid:
            return Response({'error': 'openid required'}, status=400)
        try:
            user = User.objects.get(openid=openid)
        except User.DoesNotExist:
            return Response({'error': 'user not found'}, status=404)
        return Response(UserSerializer(user).data)
