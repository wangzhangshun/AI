import os
import django
import sys

# 设置Django环境
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BASE_DIR)
sys.path.append(PROJECT_DIR)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from users.models import User
from words.models import Word, Question
from testsys.models import TestRecord, TestDetail
from django.utils import timezone

# 用户
user, _ = User.objects.get_or_create(openid='test_openid_001', defaults={
    'nickname': '测试用户',
    'avatar': 'https://example.com/avatar.png',
})
user2, _ = User.objects.get_or_create(openid='test_openid_002', defaults={
    'nickname': '测试用户2',
    'avatar': 'https://example.com/avatar2.png',
})

# 单词
word1, _ = Word.objects.get_or_create(word='apple', defaults={'meaning': '苹果', 'level': 'CET4', 'difficulty': 1})
word2, _ = Word.objects.get_or_create(word='banana', defaults={'meaning': '香蕉', 'level': 'CET4', 'difficulty': 1})
word3, _ = Word.objects.get_or_create(word='orange', defaults={'meaning': '橙子', 'level': 'CET4', 'difficulty': 1})
word4, _ = Word.objects.get_or_create(word='grape', defaults={'meaning': '葡萄', 'level': 'CET4', 'difficulty': 2})
word5, _ = Word.objects.get_or_create(word='pear', defaults={'meaning': '梨', 'level': 'CET4', 'difficulty': 1})

# 题目
q1, _ = Question.objects.get_or_create(word=word1, defaults={
    'options': {'A': '苹果', 'B': '香蕉', 'C': '橙子', 'D': '葡萄'},
    'answer': 'A',
    'type': 'choice',
})
q2, _ = Question.objects.get_or_create(word=word2, defaults={
    'options': {'A': '苹果', 'B': '香蕉', 'C': '橙子', 'D': '葡萄'},
    'answer': 'B',
    'type': 'choice',
})
q3, _ = Question.objects.get_or_create(word=word3, defaults={
    'options': {'A': '苹果', 'B': '香蕉', 'C': '橙子', 'D': '葡萄'},
    'answer': 'C',
    'type': 'choice',
})
q4, _ = Question.objects.get_or_create(word=word5, defaults={
    'options': {'A': '梨', 'B': '苹果', 'C': '香蕉', 'D': '葡萄'},
    'answer': 'A',
    'type': 'choice',
})

# 测试记录
record = TestRecord.objects.create(user=user, score=90, vocab_estimate=5000, created_at=timezone.now())
TestDetail.objects.create(record=record, question=q1, user_answer='A', is_correct=True)
TestDetail.objects.create(record=record, question=q2, user_answer='B', is_correct=True)
TestDetail.objects.create(record=record, question=q3, user_answer='D', is_correct=False)

record2 = TestRecord.objects.create(user=user2, score=80, vocab_estimate=4000, created_at=timezone.now())
TestDetail.objects.create(record=record2, question=q4, user_answer='A', is_correct=True)
TestDetail.objects.create(record=record2, question=q2, user_answer='C', is_correct=False)

print('测试数据插入完成') 