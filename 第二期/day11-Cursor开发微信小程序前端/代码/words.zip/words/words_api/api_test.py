import requests
import json

BASE_URL = 'http://127.0.0.1:8000'

# 1. 微信登录
def test_login():
    url = f'{BASE_URL}/api/login/'
    data = {
        'openid': 'test_openid_001',
        'nickname': '测试用户',
        'avatar': 'https://example.com/avatar.png'
    }
    resp = requests.post(url, json=data)
    print('1. 登录:', resp.status_code, resp.json())

# 2. 获取用户信息
def test_user_profile():
    url = f'{BASE_URL}/api/user/profile/?openid=test_openid_001'
    resp = requests.get(url)
    print('2. 用户信息:', resp.status_code, resp.json())

# 3. 获取单词列表
def test_words():
    url = f'{BASE_URL}/api/words/'
    resp = requests.get(url)
    print('3. 单词列表:', resp.status_code, resp.json())

# 4. 获取题目列表
def test_questions():
    url = f'{BASE_URL}/api/questions/?difficulty=2&num=10'
    resp = requests.get(url)
    print('4. 题目列表:', resp.status_code, resp.json())
    return resp.json()

# 5. 提交测试答案
def test_submit_test(questions):
    url = f'{BASE_URL}/api/test/submit/'
    answers = []
    for q in questions:
        answers.append({'question_id': q['id'], 'user_answer': 'A'})
    data = {
        'openid': 'test_openid_001',
        'answers': answers,
        'vocab_estimate': 5000,
        'score': 90
    }
    resp = requests.post(url, json=data)
    print('5. 提交测试:', resp.status_code, resp.json())

# 6. 获取历史测试记录
def test_history():
    url = f'{BASE_URL}/api/test/history/?openid=test_openid_001'
    resp = requests.get(url)
    print('6. 测试历史:', resp.status_code, resp.json())

if __name__ == '__main__':
    test_login()
    test_user_profile()
    test_words()
    questions = test_questions()
    test_submit_test(questions)
    test_history() 