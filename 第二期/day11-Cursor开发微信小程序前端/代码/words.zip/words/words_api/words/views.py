from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Word, Question
from .serializers import WordSerializer, QuestionSerializer

# Create your views here.

class WordListView(APIView):
    def get(self, request):
        words = Word.objects.all()
        serializer = WordSerializer(words, many=True)
        return Response(serializer.data)

class QuestionListView(APIView):
    def get(self, request):
        difficulty = request.query_params.get('difficulty')
        num = int(request.query_params.get('num', 10))
        qs = Question.objects.all()
        if difficulty:
            qs = qs.filter(word__difficulty=difficulty)
        qs = qs.order_by('?')[:num]
        serializer = QuestionSerializer(qs, many=True)
        return Response(serializer.data)
