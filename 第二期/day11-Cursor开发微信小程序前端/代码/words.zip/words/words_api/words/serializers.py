from rest_framework import serializers
from .models import Word, Question

class WordSerializer(serializers.ModelSerializer):
    class Meta:
        model = Word
        fields = ['id', 'word', 'meaning', 'level', 'difficulty']

class QuestionSerializer(serializers.ModelSerializer):
    word = WordSerializer()
    class Meta:
        model = Question
        fields = ['id', 'word', 'options', 'answer', 'type'] 