from django.db import models

# Create your models here.

class Word(models.Model):
    word = models.CharField('单词', max_length=64)
    meaning = models.CharField('释义', max_length=128)
    level = models.CharField('词汇等级', max_length=32, blank=True, null=True)
    difficulty = models.IntegerField('难度', default=1)

    class Meta:
        verbose_name = '单词'
        verbose_name_plural = '单词'

    def __str__(self):
        return self.word

class Question(models.Model):
    word = models.ForeignKey(Word, on_delete=models.CASCADE, verbose_name='关联单词')
    options = models.JSONField('选项')  # 例：{"A": "苹果", "B": "香蕉", ...}
    answer = models.CharField('正确答案', max_length=1)
    type = models.CharField('题型', max_length=16, default='choice')

    class Meta:
        verbose_name = '题目'
        verbose_name_plural = '题目'

    def __str__(self):
        return f"{self.word.word} - {self.type}"
