from django.contrib import admin
from .models import Word, Question

@admin.register(Word)
class WordAdmin(admin.ModelAdmin):
    list_display = ('id', 'word', 'meaning', 'level', 'difficulty')
    search_fields = ('word', 'meaning')
    list_filter = ('level', 'difficulty')

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('id', 'word', 'type', 'answer')
    search_fields = ('word__word',)
    list_filter = ('type',)
