// 测试图片问题修复的脚本
// 在微信开发者工具控制台中运行

// 测试网络图片加载
function testNetworkImage() {
  console.log('=== 测试网络图片加载 ===')
  
  const testImageUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
  
  wx.getImageInfo({
    src: testImageUrl,
    success: (res) => {
      console.log('✅ 网络图片加载成功:', res)
      console.log('图片尺寸:', res.width, 'x', res.height)
      console.log('图片路径:', res.path)
    },
    fail: (err) => {
      console.error('❌ 网络图片加载失败:', err)
    }
  })
}

// 测试本地图片路径
function testLocalImage() {
  console.log('\n=== 测试本地图片路径 ===')
  
  const localImagePath = '/assets/default-avatar.png'
  
  wx.getImageInfo({
    src: localImagePath,
    success: (res) => {
      console.log('✅ 本地图片加载成功:', res)
    },
    fail: (err) => {
      console.log('❌ 本地图片加载失败 (预期结果):', err)
      console.log('这是因为我们已改用网络图片，本地图片不存在')
    }
  })
}

// 检查页面中的图片引用
function checkImageReferences() {
  console.log('\n=== 检查图片引用 ===')
  
  // 检查当前页面
  const pages = getCurrentPages()
  const currentPage = pages[pages.length - 1]
  
  console.log('当前页面:', currentPage.route)
  console.log('页面数据:', currentPage.data)
  
  // 检查用户信息中的头像
  if (currentPage.data.userInfo) {
    console.log('用户头像URL:', currentPage.data.userInfo.avatarUrl)
  }
}

// 测试图片预加载
function testImagePreload() {
  console.log('\n=== 测试图片预加载 ===')
  
  const imageUrls = [
    'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
  ]
  
  imageUrls.forEach((url, index) => {
    wx.getImageInfo({
      src: url,
      success: (res) => {
        console.log(`✅ 图片${index + 1}预加载成功:`, url)
      },
      fail: (err) => {
        console.error(`❌ 图片${index + 1}预加载失败:`, url, err)
      }
    })
  })
}

// 检查网络状态
function checkNetworkStatus() {
  console.log('\n=== 检查网络状态 ===')
  
  wx.getNetworkType({
    success: (res) => {
      console.log('网络类型:', res.networkType)
      if (res.networkType === 'none') {
        console.log('⚠️ 当前无网络连接，图片可能无法加载')
      } else {
        console.log('✅ 网络连接正常')
      }
    },
    fail: (err) => {
      console.error('❌ 获取网络状态失败:', err)
    }
  })
}

// 运行所有测试
function runAllTests() {
  console.log('🖼️ 开始运行图片问题修复测试...')
  
  checkNetworkStatus()
  setTimeout(() => testNetworkImage(), 500)
  setTimeout(() => testLocalImage(), 1000)
  setTimeout(() => checkImageReferences(), 1500)
  setTimeout(() => testImagePreload(), 2000)
}

// 快速测试
function quickTest() {
  console.log('🔍 快速测试图片加载...')
  testNetworkImage()
}

// 在控制台中运行: runAllTests() 或 quickTest()
console.log('图片问题修复测试脚本已加载')
console.log('运行 runAllTests() 开始完整测试')
console.log('运行 quickTest() 开始快速测试') 