// 测试答案判断修复的脚本
// 在微信开发者工具控制台中运行

// 模拟题目数据
const mockQuestion = {
  id: 1,
  word: 'apple',
  options: ['苹果', '香蕉', '橙子', '葡萄'],
  correct_answer: 'A',
  difficulty: 1,
  explanation: 'apple 是苹果的意思'
}

// 测试答案判断逻辑
function testAnswerLogic() {
  console.log('=== 测试答案判断逻辑 ===')
  
  // 模拟选择正确答案 (A = 索引0)
  const selectedAnswer = 0
  const correctAnswer = mockQuestion.correct_answer.charCodeAt(0) - 65 // A=0
  
  console.log('题目:', mockQuestion.word)
  console.log('选项:', mockQuestion.options)
  console.log('正确答案:', mockQuestion.correct_answer)
  console.log('正确答案索引:', correctAnswer)
  console.log('用户选择索引:', selectedAnswer)
  console.log('用户选择标签:', String.fromCharCode(65 + selectedAnswer))
  console.log('判断结果:', selectedAnswer === correctAnswer ? '正确' : '错误')
  
  // 测试所有选项
  console.log('\n=== 测试所有选项 ===')
  mockQuestion.options.forEach((option, index) => {
    const isCorrect = index === correctAnswer
    const label = String.fromCharCode(65 + index)
    console.log(`${label}. ${option} - ${isCorrect ? '✓' : '✗'}`)
  })
}

// 测试数据转换
function testDataConversion() {
  console.log('\n=== 测试数据转换 ===')
  
  // 模拟后端返回的数据格式
  const backendQuestion = {
    id: 1,
    word: { word: 'apple', meaning: '苹果' },
    options: { A: '苹果', B: '香蕉', C: '橙子', D: '葡萄' },
    answer: 'A'
  }
  
  console.log('后端数据:', backendQuestion)
  
  // 模拟转换过程
  const optionsArray = []
  optionsArray.push(backendQuestion.options.A || '')
  optionsArray.push(backendQuestion.options.B || '')
  optionsArray.push(backendQuestion.options.C || '')
  optionsArray.push(backendQuestion.options.D || '')
  
  const convertedQuestion = {
    id: backendQuestion.id,
    word: backendQuestion.word.word,
    options: optionsArray,
    correct_answer: backendQuestion.answer,
    explanation: `${backendQuestion.word.word} 的意思是 ${backendQuestion.word.meaning}`
  }
  
  console.log('转换后数据:', convertedQuestion)
  
  // 测试答案判断
  const correctIndex = convertedQuestion.correct_answer.charCodeAt(0) - 65
  console.log('正确答案索引:', correctIndex)
  console.log('正确答案:', convertedQuestion.options[correctIndex])
}

// 测试实际API数据
function testApiData() {
  console.log('\n=== 测试API数据 ===')
  
  wx.request({
    url: 'http://127.0.0.1:8000/api/questions/?difficulty=2&num=1',
    method: 'GET',
    success: (res) => {
      console.log('API返回数据:', res.data)
      
      if (res.data && res.data.length > 0) {
        const question = res.data[0]
        console.log('第一道题:', question)
        
        // 测试转换
        const optionsArray = []
        if (question.options && typeof question.options === 'object') {
          optionsArray.push(question.options.A || '')
          optionsArray.push(question.options.B || '')
          optionsArray.push(question.options.C || '')
          optionsArray.push(question.options.D || '')
        }
        
        console.log('转换后选项:', optionsArray)
        console.log('正确答案:', question.answer)
        
        // 测试答案判断
        const correctIndex = question.answer.charCodeAt(0) - 65
        console.log('正确答案索引:', correctIndex)
        console.log('正确答案内容:', optionsArray[correctIndex])
      }
    },
    fail: (err) => {
      console.error('API请求失败:', err)
    }
  })
}

// 运行所有测试
function runAllTests() {
  console.log('🚀 开始运行答案判断修复测试...')
  testAnswerLogic()
  testDataConversion()
  setTimeout(() => testApiData(), 1000)
}

// 在控制台中运行: runAllTests()
console.log('答案判断修复测试脚本已加载')
console.log('运行 runAllTests() 开始测试') 