// app.js
App({
  globalData: {
    userInfo: null,
    openid: null,
    baseUrl: 'http://192.168.71.100:8000',
    // 假数据，用于离线测试
    mockQuestions: [
      {
        id: 1,
        word: 'apple',
        options: ['苹果', '香蕉', '橙子', '葡萄'],
        correct_answer: 'A',
        difficulty: 1,
        explanation: 'apple 是苹果的意思'
      },
      {
        id: 2,
        word: 'beautiful',
        options: ['美丽的', '丑陋的', '高大的', '矮小的'],
        correct_answer: 'A',
        difficulty: 2,
        explanation: 'beautiful 是美丽的的意思'
      },
      {
        id: 3,
        word: 'computer',
        options: ['电脑', '手机', '平板', '电视'],
        correct_answer: 'A',
        difficulty: 2,
        explanation: 'computer 是电脑的意思'
      },
      {
        id: 4,
        word: 'democracy',
        options: ['民主', '专制', '共和', '联邦'],
        correct_answer: 'A',
        difficulty: 4,
        explanation: 'democracy 是民主的意思'
      },
      {
        id: 5,
        word: 'enthusiasm',
        options: ['热情', '冷漠', '愤怒', '悲伤'],
        correct_answer: 'A',
        difficulty: 4,
        explanation: 'enthusiasm 是热情的意思'
      }
    ]
  },

  onLaunch() {
    // 获取用户openid
    this.getOpenid()
    
    // 检查网络状态
    this.checkNetworkStatus()
  },

  getOpenid() {
    // 使用固定的测试openid，与后端测试数据保持一致
    this.globalData.openid = 'test_openid_001'
  },

  checkNetworkStatus() {
    wx.getNetworkType({
      success: (res) => {
        console.log('网络类型:', res.networkType)
        if (res.networkType === 'none') {
          wx.showToast({
            title: '当前无网络连接',
            icon: 'none',
            duration: 2000
          })
        }
      }
    })
  }
})
