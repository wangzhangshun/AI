const app = getApp()
const { API, handleError } = require('../../utils/api.js')

Page({
  data: {
    questions: [],
    currentIndex: 0,
    currentQuestion: null,
    selectedAnswer: null,
    showResult: false,
    answers: [],
    correctCount: 0,
    correctAnswerIndex: 0,
    optionLabels: ['A', 'B', 'C', 'D']
  },

  onLoad() {
    this.loadQuestions()
  },

  // 加载题目
  loadQuestions() {
    // 使用全局假数据
    const questions = app.globalData.mockQuestions
    this.setData({
      questions: questions,
      currentQuestion: questions[0],
      correctAnswerIndex: this.getCorrectAnswerIndex(questions[0])
    })
  },

  // 选择选项
  selectOption(e) {
    if (this.data.showResult) return // 已显示结果时不允许选择
    
    const index = e.currentTarget.dataset.index
    this.setData({
      selectedAnswer: index
    })
  },

  // 提交答案
  submitAnswer() {
    if (this.data.selectedAnswer === null) return

    const currentQuestion = this.data.currentQuestion
    const selectedAnswer = this.data.selectedAnswer
    const correctAnswerIndex = this.data.correctAnswerIndex
    const isCorrect = selectedAnswer === correctAnswerIndex

    console.log('提交答案:', {
      selectedAnswer,
      correctAnswerIndex,
      isCorrect,
      selectedLabel: this.data.optionLabels[selectedAnswer],
      correctLabel: this.data.optionLabels[correctAnswerIndex]
    })

    // 记录答案
    const answers = this.data.answers
    answers.push({
      question_id: currentQuestion.id,
      user_answer: this.data.optionLabels[selectedAnswer],
      is_correct: isCorrect
    })

    this.setData({
      showResult: true,
      answers: answers,
      correctCount: this.data.correctCount + (isCorrect ? 1 : 0)
    })
  },

  // 下一题
  nextQuestion() {
    const nextIndex = this.data.currentIndex + 1
    
    if (nextIndex >= this.data.questions.length) {
      // 测试完成，跳转到结果页
      this.completeTest()
    } else {
      // 显示下一题
      const nextQuestion = this.data.questions[nextIndex]
      this.setData({
        currentIndex: nextIndex,
        currentQuestion: nextQuestion,
        selectedAnswer: null,
        showResult: false,
        correctAnswerIndex: this.getCorrectAnswerIndex(nextQuestion)
      })
    }
  },

  // 完成测试
  async completeTest() {
    const result = {
      totalQuestions: this.data.questions.length,
      correctCount: this.data.correctCount,
      score: Math.round(this.data.correctCount / this.data.questions.length * 100),
      vocabEstimate: this.calculateVocabEstimate(),
      answers: this.data.answers
    }

    // 将结果存储到全局数据
    app.globalData.testResult = result

    // 提交测试结果到后端
    try {
      const submitData = {
        openid: app.globalData.openid,
        answers: this.data.answers.map(ans => ({
          question_id: ans.question_id,
          user_answer: ans.user_answer
        })),
        vocab_estimate: result.vocabEstimate,
        score: result.score
      }

      const submitResult = await API.submitTest(submitData)
      console.log('提交测试结果成功:', submitResult)
    } catch (error) {
      console.error('提交测试结果失败:', error)
      handleError(error)
    }

    // 跳转到结果页
    wx.redirectTo({
      url: '/pages/result/index'
    })
  },

  // 计算词汇量估算
  calculateVocabEstimate() {
    const score = this.data.correctCount / this.data.questions.length
    const baseVocab = 2000 // 基础词汇量
    
    if (score >= 0.8) return baseVocab + 8000
    if (score >= 0.6) return baseVocab + 5000
    if (score >= 0.4) return baseVocab + 3000
    if (score >= 0.2) return baseVocab + 1000
    return baseVocab
  },

  // 获取正确答案索引
  getCorrectAnswerIndex(question) {
    if (!question || !question.correct_answer) return 0
    const correctAnswer = question.correct_answer
    return correctAnswer.charCodeAt(0) - 65 // A=0, B=1, C=2, D=3
  }
}) 