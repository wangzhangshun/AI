const app = getApp()

Page({
  data: {
    result: {}
  },

  onLoad() {
    // 获取测试结果
    const result = app.globalData.testResult
    if (!result) {
      // 如果没有结果数据，跳转到首页
      wx.redirectTo({
        url: '/pages/home/index'
      })
      return
    }

    this.setData({
      result: result
    })

    // 保存测试结果到历史记录
    this.saveTestResult(result)
  },

  // 保存测试结果
  saveTestResult(result) {
    const history = wx.getStorageSync('testHistory') || []
    const testRecord = {
      id: Date.now(),
      date: new Date().toLocaleString(),
      vocabEstimate: result.vocabEstimate,
      score: result.score,
      correctCount: result.correctCount,
      totalQuestions: result.totalQuestions,
      answers: result.answers
    }
    
    history.unshift(testRecord)
    
    // 只保留最近10次测试记录
    if (history.length > 10) {
      history.splice(10)
    }
    
    wx.setStorageSync('testHistory', history)
    console.log('测试结果已保存到本地存储')
  },

  // 获取词汇水平
  getVocabLevel() {
    const vocab = this.data.result.vocabEstimate
    
    if (vocab >= 10000) return '高级水平'
    if (vocab >= 7000) return '中高级水平'
    if (vocab >= 5000) return '中级水平'
    if (vocab >= 3000) return '中初级水平'
    return '初级水平'
  },

  // 获取词汇量说明
  getVocabExplanation() {
    const vocab = this.data.result.vocabEstimate
    
    if (vocab >= 10000) {
      return '您的词汇量非常丰富，能够理解复杂的英语文本，适合阅读英文原著和专业文献。'
    } else if (vocab >= 7000) {
      return '您的词汇量良好，能够应对大部分日常英语交流，适合阅读英文新闻和一般文学作品。'
    } else if (vocab >= 5000) {
      return '您的词汇量达到中等水平，能够进行基本的英语交流，建议继续扩充词汇量。'
    } else if (vocab >= 3000) {
      return '您的词汇量处于中初级水平，建议多学习常用词汇，提高英语表达能力。'
    } else {
      return '您的词汇量还有提升空间，建议从基础词汇开始，循序渐进地学习。'
    }
  },

  // 重新测试
  retest() {
    wx.redirectTo({
      url: '/pages/test/index'
    })
  },

  // 分享结果
  shareResult() {
    const result = this.data.result
    const level = this.getVocabLevel()
    
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
    
    // 模拟分享
    wx.showToast({
      title: '分享功能开发中',
      icon: 'none'
    })
  },

  // 跳转到个人中心
  goToProfile() {
    wx.navigateTo({
      url: '/pages/profile/index'
    })
  },

  // 分享给朋友
  onShareAppMessage() {
    const result = this.data.result
    const level = this.getVocabLevel()
    
    return {
      title: `我的英语词汇量测试结果：${result.vocabEstimate}个单词，${level}`,
      path: '/pages/home/index'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    const result = this.data.result
    const level = this.getVocabLevel()
    
    return {
      title: `英语词汇量测试：${result.vocabEstimate}个单词，${level}`
    }
  }
}) 