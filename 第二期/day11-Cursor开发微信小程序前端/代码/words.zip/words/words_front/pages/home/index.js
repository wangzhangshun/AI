const app = getApp()
const { API, handleError, DataConverter } = require('../../utils/api.js')

Page({
  data: {
    userInfo: {},
    openid: '',
    isLoading: false
  },

  onLoad() {
    this.setData({
      openid: app.globalData.openid
    })
    // 先登录，登录成功后再获取用户信息
    this.loginUser()
  },

  onShow() {
    // 页面显示时，如果还没有用户信息，则重新获取
    if (!this.data.userInfo.nickName) {
      this.getUserInfo()
    }
  },

  // 用户登录
  async loginUser() {
    try {
      this.setData({ isLoading: true })
      
      const loginData = {
        openid: this.data.openid,
        nickname: '测试用户',
        avatar: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
      }

      const result = await API.login(loginData)
      console.log('登录成功:', result)
      
      // 登录成功后获取用户信息
      this.getUserInfo()
    } catch (error) {
      console.error('登录失败:', error)
      handleError(error)
      // 登录失败时使用默认用户信息
      this.getUserInfo()
    } finally {
      this.setData({ isLoading: false })
    }
  },

  // 获取用户信息
  async getUserInfo() {
    try {
      const userInfo = await API.getUserProfile(this.data.openid)
      console.log('获取用户信息成功:', userInfo)
      
      this.setData({
        userInfo: {
          nickName: userInfo.nickname,
          avatarUrl: userInfo.avatar
        }
      })
    } catch (error) {
      console.error('获取用户信息失败:', error)
      // 使用默认用户信息
      this.setData({
        userInfo: {
          nickName: '测试用户',
          avatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
        }
      })
    }
  },

  // 开始测试
  async startTest() {
    wx.showLoading({
      title: '准备测试中...'
    })

    try {
      // 尝试从后端获取题目
      const questions = await API.getQuestions(2, 5) // 难度2，5道题
      console.log('获取题目成功:', questions)
      
      // 转换题目格式
      const convertedQuestions = DataConverter.convertQuestions(questions)
      
      // 更新全局数据
      app.globalData.mockQuestions = convertedQuestions
      
      wx.hideLoading()
      wx.navigateTo({
        url: '/pages/test/index'
      })
    } catch (error) {
      console.error('获取题目失败:', error)
      handleError(error)
      
      // 如果获取失败，使用默认题目
      wx.hideLoading()
      wx.navigateTo({
        url: '/pages/test/index'
      })
    }
  },

  // 跳转到个人中心
  goToProfile() {
    wx.navigateTo({
      url: '/pages/profile/index'
    })
  }
}) 