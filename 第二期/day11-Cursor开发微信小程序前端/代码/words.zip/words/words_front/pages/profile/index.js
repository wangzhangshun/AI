const app = getApp()
const { API, handleError, DataConverter } = require('../../utils/api.js')

Page({
  data: {
    userInfo: {},
    openid: '',
    testHistory: [],
    totalTests: 0,
    bestScore: 0,
    bestVocab: 0,
    isLoading: false
  },

  onLoad() {
    this.setData({
      openid: app.globalData.openid
    })
    this.getUserInfo()
    this.loadTestHistory()
  },

  onShow() {
    // 页面显示时刷新数据
    this.loadTestHistory()
  },

  // 获取用户信息
  async getUserInfo() {
    try {
      const userInfo = await API.getUserProfile(this.data.openid)
      console.log('获取用户信息成功:', userInfo)
      
      this.setData({
        userInfo: {
          nickName: userInfo.nickname,
          avatarUrl: userInfo.avatar
        }
      })
    } catch (error) {
      console.error('获取用户信息失败:', error)
      // 使用默认用户信息
      this.setData({
        userInfo: {
          nickName: '测试用户',
          avatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
        }
      })
    }
  },

  // 加载测试历史
  async loadTestHistory() {
    try {
      this.setData({ isLoading: true })
      
      // 尝试从后端获取历史记录
      const backendHistory = await API.getTestHistory(this.data.openid)
      console.log('获取历史记录成功:', backendHistory)
      
      // 转换历史记录格式
      const convertedHistory = DataConverter.convertHistory(backendHistory)
      
      this.setData({
        testHistory: convertedHistory,
        totalTests: convertedHistory.length
      })

      // 计算统计数据
      this.calculateStats(convertedHistory)
    } catch (error) {
      console.error('获取历史记录失败:', error)
      handleError(error)
      
      // 如果获取失败，使用本地存储的历史记录
      const localHistory = wx.getStorageSync('testHistory') || []
      this.setData({
        testHistory: localHistory,
        totalTests: localHistory.length
      })
      this.calculateStats(localHistory)
    } finally {
      this.setData({ isLoading: false })
    }
  },

  // 计算统计数据
  calculateStats(history) {
    if (history.length === 0) {
      this.setData({
        bestScore: 0,
        bestVocab: 0
      })
      return
    }

    let bestScore = 0
    let bestVocab = 0

    history.forEach(test => {
      if (test.score > bestScore) {
        bestScore = test.score
      }
      if (test.vocabEstimate > bestVocab) {
        bestVocab = test.vocabEstimate
      }
    })

    this.setData({
      bestScore: bestScore,
      bestVocab: bestVocab
    })
  },

  // 获取词汇水平
  getVocabLevel(vocab) {
    if (vocab >= 10000) return '高级'
    if (vocab >= 7000) return '中高级'
    if (vocab >= 5000) return '中级'
    if (vocab >= 3000) return '中初级'
    return '初级'
  },

  // 查看测试详情
  viewTestDetail(e) {
    const test = e.currentTarget.dataset.test
    
    wx.showModal({
      title: '测试详情',
      content: `测试时间：${test.date}\n正确率：${test.score}%\n词汇量：${test.vocabEstimate}个单词\n正确题数：${test.correctCount}/${test.totalQuestions}`,
      showCancel: false,
      confirmText: '确定'
    })
  },

  // 开始新测试
  startNewTest() {
    wx.navigateTo({
      url: '/pages/test/index'
    })
  },

  // 显示关于信息
  showAbout() {
    wx.showModal({
      title: '关于应用',
      content: '英语单词量测试小程序\n版本：1.0.0\n\n帮助用户快速评估英语词汇水平，提供个性化的学习建议。',
      showCancel: false,
      confirmText: '确定'
    })
  },

  // 显示反馈
  showFeedback() {
    wx.showModal({
      title: '意见反馈',
      content: '感谢您的使用！\n\n如有问题或建议，请通过以下方式联系我们：\n\n邮箱：feedback@example.com\n微信：vocab_test',
      showCancel: false,
      confirmText: '确定'
    })
  }
}) 