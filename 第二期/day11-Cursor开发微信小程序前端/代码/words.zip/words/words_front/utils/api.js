const app = getApp()

// API基础配置
const API_CONFIG = {
  baseUrl: 'http://192.168.71.100:8000',
  timeout: 10000
}

// 请求封装
function request(options) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: API_CONFIG.baseUrl + options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'Content-Type': 'application/json',
        ...options.header
      },
      timeout: API_CONFIG.timeout,
      success: (res) => {
        if (res.statusCode === 200) {
          resolve(res.data)
        } else {
          reject(new Error(`请求失败: ${res.statusCode} - ${res.data?.error || '未知错误'}`))
        }
      },
      fail: (err) => {
        reject(new Error(`网络错误: ${err.errMsg}`))
      }
    })
  })
}

// API接口定义
const API = {
  // 用户登录
  login: (data) => {
    return request({
      url: '/api/login/',
      method: 'POST',
      data: data
    })
  },

  // 获取用户信息
  getUserProfile: (openid) => {
    return request({
      url: `/api/user/profile/?openid=${openid}`,
      method: 'GET'
    })
  },

  // 获取单词列表
  getWords: () => {
    return request({
      url: '/api/words/',
      method: 'GET'
    })
  },

  // 获取题目列表
  getQuestions: (difficulty, num) => {
    return request({
      url: `/api/questions/?difficulty=${difficulty}&num=${num}`,
      method: 'GET'
    })
  },

  // 提交测试答案
  submitTest: (data) => {
    return request({
      url: '/api/test/submit/',
      method: 'POST',
      data: data
    })
  },

  // 获取测试历史
  getTestHistory: (openid) => {
    return request({
      url: `/api/test/history/?openid=${openid}`,
      method: 'GET'
    })
  }
}

// 错误处理
function handleError(error) {
  console.error('API Error:', error)
  wx.showToast({
    title: error.message || '请求失败',
    icon: 'none',
    duration: 2000
  })
}

// 数据转换工具
const DataConverter = {
  // 将后端题目数据转换为小程序格式
  convertQuestions: (backendQuestions) => {
    return backendQuestions.map(q => {
      // 将选项对象转换为数组
      const optionsArray = []
      if (q.options && typeof q.options === 'object') {
        // 如果是对象格式，转换为数组
        if (Array.isArray(q.options)) {
          optionsArray.push(...q.options)
        } else {
          // 对象格式：{A: '苹果', B: '香蕉', C: '橙子', D: '葡萄'}
          optionsArray.push(q.options.A || '')
          optionsArray.push(q.options.B || '')
          optionsArray.push(q.options.C || '')
          optionsArray.push(q.options.D || '')
        }
      }

      return {
        id: q.id,
        word: q.word.word,
        options: optionsArray,
        correct_answer: q.answer,
        difficulty: q.word.difficulty,
        explanation: `${q.word.word} 的意思是 ${q.word.meaning}`
      }
    })
  },

  // 将后端历史记录转换为小程序格式
  convertHistory: (backendHistory) => {
    return backendHistory.map(record => ({
      id: record.id,
      date: new Date(record.created_at).toLocaleString(),
      vocabEstimate: record.vocab_estimate,
      score: record.score,
      correctCount: Math.round(record.score / 100 * 5), // 假设5道题
      totalQuestions: 5
    }))
  }
}

// 导出
module.exports = {
  API,
  request,
  handleError,
  DataConverter
} 