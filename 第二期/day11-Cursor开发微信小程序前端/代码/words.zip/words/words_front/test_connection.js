// 小程序与后端连接测试脚本
// 在微信开发者工具的控制台中运行此脚本

const API_CONFIG = {
  baseUrl: 'http://127.0.0.1:8000',
  timeout: 10000
}

// 测试函数
function testConnection() {
  console.log('开始测试小程序与后端连接...')
  
  // 测试1: 获取单词列表
  testGetWords()
  
  // 测试2: 获取题目列表
  testGetQuestions()
  
  // 测试3: 用户登录
  testLogin()
  
  // 测试4: 提交测试答案
  testSubmitTest()
  
  // 测试5: 获取历史记录
  testGetHistory()
}

// 测试获取单词列表
function testGetWords() {
  console.log('\n=== 测试获取单词列表 ===')
  
  wx.request({
    url: API_CONFIG.baseUrl + '/api/words/',
    method: 'GET',
    success: (res) => {
      console.log('✅ 获取单词列表成功:', res.data)
      console.log('单词数量:', res.data.length)
    },
    fail: (err) => {
      console.error('❌ 获取单词列表失败:', err)
    }
  })
}

// 测试获取题目列表
function testGetQuestions() {
  console.log('\n=== 测试获取题目列表 ===')
  
  wx.request({
    url: API_CONFIG.baseUrl + '/api/questions/?difficulty=2&num=5',
    method: 'GET',
    success: (res) => {
      console.log('✅ 获取题目列表成功:', res.data)
      console.log('题目数量:', res.data.length)
      if (res.data.length > 0) {
        console.log('第一道题:', res.data[0])
      }
    },
    fail: (err) => {
      console.error('❌ 获取题目列表失败:', err)
    }
  })
}

// 测试用户登录
function testLogin() {
  console.log('\n=== 测试用户登录 ===')
  
  const loginData = {
    openid: 'test_openid_' + Date.now(),
    nickname: '测试用户',
    avatar: 'https://example.com/avatar.png'
  }
  
  wx.request({
    url: API_CONFIG.baseUrl + '/api/login/',
    method: 'POST',
    data: loginData,
    header: {
      'Content-Type': 'application/json'
    },
    success: (res) => {
      console.log('✅ 用户登录成功:', res.data)
      // 保存openid用于后续测试
      window.testOpenid = loginData.openid
    },
    fail: (err) => {
      console.error('❌ 用户登录失败:', err)
    }
  })
}

// 测试提交测试答案
function testSubmitTest() {
  console.log('\n=== 测试提交测试答案 ===')
  
  const testData = {
    openid: window.testOpenid || 'test_openid_001',
    answers: [
      { question_id: 1, user_answer: 'A' },
      { question_id: 2, user_answer: 'B' }
    ],
    vocab_estimate: 5000,
    score: 80
  }
  
  wx.request({
    url: API_CONFIG.baseUrl + '/api/test/submit/',
    method: 'POST',
    data: testData,
    header: {
      'Content-Type': 'application/json'
    },
    success: (res) => {
      console.log('✅ 提交测试答案成功:', res.data)
    },
    fail: (err) => {
      console.error('❌ 提交测试答案失败:', err)
    }
  })
}

// 测试获取历史记录
function testGetHistory() {
  console.log('\n=== 测试获取历史记录 ===')
  
  const openid = window.testOpenid || 'test_openid_001'
  
  wx.request({
    url: API_CONFIG.baseUrl + `/api/test/history/?openid=${openid}`,
    method: 'GET',
    success: (res) => {
      console.log('✅ 获取历史记录成功:', res.data)
      console.log('历史记录数量:', res.data.length)
    },
    fail: (err) => {
      console.error('❌ 获取历史记录失败:', err)
    }
  })
}

// 测试网络连接
function testNetwork() {
  console.log('\n=== 测试网络连接 ===')
  
  wx.request({
    url: API_CONFIG.baseUrl + '/api/',
    method: 'GET',
    success: (res) => {
      console.log('✅ 网络连接正常:', res.statusCode)
    },
    fail: (err) => {
      console.error('❌ 网络连接失败:', err)
      console.log('请检查后端服务是否启动在 http://127.0.0.1:8000')
    }
  })
}

// 测试用户信息获取
function testUserProfile() {
  console.log('\n=== 测试获取用户信息 ===')
  
  const openid = window.testOpenid || 'test_openid_001'
  
  wx.request({
    url: API_CONFIG.baseUrl + `/api/user/profile/?openid=${openid}`,
    method: 'GET',
    success: (res) => {
      console.log('✅ 获取用户信息成功:', res.data)
    },
    fail: (err) => {
      console.error('❌ 获取用户信息失败:', err)
    }
  })
}

// 运行所有测试
function runAllTests() {
  console.log('🚀 开始运行所有连接测试...')
  console.log('后端地址:', API_CONFIG.baseUrl)
  
  testNetwork()
  setTimeout(() => testConnection(), 1000)
  setTimeout(() => testUserProfile(), 2000)
}

// 运行基础测试
function runBasicTests() {
  console.log('🔧 运行基础连接测试...')
  testNetwork()
  testGetWords()
  testGetQuestions()
}

// 在控制台中运行: runAllTests() 或 runBasicTests()
console.log('连接测试脚本已加载')
console.log('运行 runAllTests() 开始完整测试')
console.log('运行 runBasicTests() 开始基础测试') 